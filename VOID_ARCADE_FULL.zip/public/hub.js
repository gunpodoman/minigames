(() => {
  'use strict';

  const grid = document.getElementById('gameGrid');
  const emptyState = document.getElementById('emptyState');
  const onlineStatus = document.getElementById('onlineStatus');
  const aboutList = document.getElementById('aboutGameList');
  const numberFormatter = new Intl.NumberFormat('ko-KR');

  let soundOn = localStorage.getItem('voidArcadeSound') !== 'off';
  let audioContext = null;
  const soundButton = document.getElementById('soundToggle');
  soundButton.textContent = soundOn ? 'SOUND ON' : 'SOUND OFF';

  function blip(frequency = 420) {
    if (!soundOn) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    audioContext ||= new Ctx();
    const now = audioContext.currentTime;
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(frequency, now);
    osc.frequency.exponentialRampToValueAtTime(frequency * 1.45, now + 0.07);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.045, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);
    osc.connect(gain).connect(audioContext.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  soundButton.addEventListener('click', () => {
    soundOn = !soundOn;
    localStorage.setItem('voidArcadeSound', soundOn ? 'on' : 'off');
    soundButton.textContent = soundOn ? 'SOUND ON' : 'SOUND OFF';
    if (soundOn) blip(510);
  });

  const dialog = document.getElementById('aboutDialog');
  document.getElementById('aboutButton').addEventListener('click', () => dialog.showModal());
  document.getElementById('closeAbout').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });

  function escapeText(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('\"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function safeColor(value, fallback) {
    return /^#[0-9a-f]{6}$/i.test(value || '') ? value : fallback;
  }

  function formatRecord(game) {
    if (!game.record?.storageKey) return game.record?.fallback ?? '—';
    const raw = localStorage.getItem(game.record.storageKey);
    const fallback = game.record.fallback ?? 0;
    const parsed = raw === null ? fallback : Number(raw);
    const value = Number.isFinite(parsed) ? parsed : fallback;
    const formatted = game.record.format === 'raw' ? String(value) : numberFormatter.format(value);
    return `${game.record.prefix || ''}${formatted}${game.record.suffix || ''}`;
  }

  function previewMarkup(game) {
    if (game.cover) {
      return `<img class="cover-image" src="${encodeURI(game.cover)}" alt="" loading="lazy">`;
    }
    const preview = game.preview || 'generic';
    if (preview === 'echo-orbit') {
      return '<div class="orbit o1"></div><div class="orbit o2"></div><div class="orbit o3"></div><div class="echo-core"></div><div class="echo-player"></div><div class="echo-shadow s1"></div><div class="echo-shadow s2"></div>';
    }
    if (preview === 'glyph-grid') {
      return '<div class="glyph-board" aria-hidden="true"></div>';
    }
    const initials = escapeText(game.shortTitle || game.title).split(/\s|\/+/).filter(Boolean).slice(0, 2).map(word => word[0]).join('').toUpperCase();
    return `<div class="generic-shape shape-a"></div><div class="generic-shape shape-b"></div><div class="generic-monogram">${initials || 'VA'}</div>`;
  }

  function createCard(game, index) {
    const article = document.createElement('article');
    article.className = `game-card ${game.featured ? 'featured' : ''}`;
    article.tabIndex = 0;
    article.style.setProperty('--accent', safeColor(game.accent, '#62f5ff'));
    article.style.setProperty('--accent2', safeColor(game.accent2, '#a77cff'));
    article.style.setProperty('--card-delay', `${Math.min(index * 55, 440)}ms`);
    article.dataset.href = game.href;

    const ribbon = game.badge ? `<div class="featured-ribbon">${escapeText(game.badge)}</div>` : '';
    const tags = (game.tags || []).slice(0, 4).map(tag => `<span>${escapeText(tag)}</span>`).join('');
    const buttonLabel = escapeText(game.buttonLabel || 'PLAY NOW');
    const recordLabel = escapeText(game.record?.label || 'LOCAL RECORD');
    const genre = escapeText(game.genre || 'BROWSER GAME');

    article.innerHTML = `
      ${ribbon}
      <div class="preview preview-${escapeText(game.preview || 'generic')}">
        ${previewMarkup(game)}
        <div class="preview-grid"></div>
        <span class="genre-badge">${genre}</span>
      </div>
      <div class="card-body">
        <div class="title-row"><h2>${escapeText(game.title)}</h2><span class="version">${escapeText(game.version || 'v1.0')}</span></div>
        <p>${escapeText(game.description || '')}</p>
        <div class="tag-row">${tags}</div>
        <div class="card-footer">
          <div class="record"><small>${recordLabel}</small><strong>${formatRecord(game)}</strong></div>
          <a class="play-button" href="${encodeURI(game.href)}">${buttonLabel} <b>↗</b></a>
        </div>
      </div>`;

    article.addEventListener('pointerenter', () => blip(390 + (index % 5) * 35));
    article.addEventListener('click', event => {
      if (!event.target.closest('a')) location.href = game.href;
    });
    article.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        location.href = game.href;
      }
    });

    if (game.preview === 'glyph-grid' && !game.cover) buildGlyphPreview(article.querySelector('.glyph-board'));
    return article;
  }

  function buildGlyphPreview(board) {
    if (!board) return;
    const shapes = ['triangle', 'circle', 'square', 'diamond'];
    for (let i = 0; i < 36; i += 1) {
      const cell = document.createElement('i');
      cell.className = `glyph-cell ${shapes[(i + Math.floor(i / 6) * 2) % shapes.length]}`;
      cell.style.setProperty('--i', i);
      board.appendChild(cell);
    }
  }

  function renderAbout(games) {
    aboutList.replaceChildren();
    games.forEach(game => {
      const row = document.createElement('div');
      const title = document.createElement('b');
      const genre = document.createElement('span');
      title.textContent = game.title;
      genre.textContent = game.genre || 'Browser game';
      row.append(title, genre);
      aboutList.appendChild(row);
    });
  }

  async function loadCatalog() {
    try {
      const response = await fetch(`games/catalog.json?v=${Date.now()}`, { cache: 'no-store' });
      if (!response.ok) throw new Error(`catalog ${response.status}`);
      const payload = await response.json();
      const games = Array.isArray(payload.games) ? payload.games : [];
      grid.replaceChildren();
      if (!games.length) {
        grid.hidden = true;
        emptyState.hidden = false;
        onlineStatus.textContent = '0 GAMES ONLINE';
        renderAbout([]);
        return;
      }
      games.forEach((game, index) => grid.appendChild(createCard(game, index)));
      onlineStatus.textContent = `${games.length} GAME${games.length === 1 ? '' : 'S'} ONLINE`;
      renderAbout(games);
    } catch (error) {
      console.error(error);
      grid.innerHTML = '<div class="catalog-error"><strong>게임 목록을 불러오지 못했습니다.</strong><span>GitHub Actions 배포가 완료되었는지 확인해 주십시오.</span></div>';
      onlineStatus.textContent = 'VAULT OFFLINE';
    }
  }

  loadCatalog();
})();
