#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
BUILTIN_PACKAGES = ROOT / "packages"
REPOSITORY = Path(os.environ.get("GITHUB_WORKSPACE", ROOT)).resolve()
OUTPUT = ROOT / "_site"
MAX_FILES = 1500
MAX_UNCOMPRESSED_BYTES = 200 * 1024 * 1024
ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{1,48}[a-z0-9]$")
COLOR_PATTERN = re.compile(r"^#[0-9a-fA-F]{6}$")


class BuildError(RuntimeError):
    pass


def fail(message: str) -> None:
    raise BuildError(message)


def normalize_member(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        fail(f"안전하지 않은 ZIP 경로: {name}")
    return path


def is_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def find_manifest_base(names: list[PurePosixPath], package_name: str) -> PurePosixPath:
    candidates = [path for path in names if path.name == "game.json"]
    if len(candidates) != 1:
        fail(f"{package_name}: game.json은 ZIP 안에 정확히 하나 있어야 합니다.")
    return candidates[0].parent


def read_manifest(archive: zipfile.ZipFile, member: str, package_name: str) -> dict:
    try:
        data = json.loads(archive.read(member).decode("utf-8-sig"))
    except UnicodeDecodeError as exc:
        fail(f"{package_name}: game.json은 UTF-8이어야 합니다. ({exc})")
    except json.JSONDecodeError as exc:
        fail(f"{package_name}: game.json JSON 문법 오류 — {exc}")
    if not isinstance(data, dict):
        fail(f"{package_name}: game.json 최상위 값은 객체여야 합니다.")
    return data


def required_text(manifest: dict, key: str, package_name: str, max_len: int) -> str:
    value = manifest.get(key)
    if not isinstance(value, str) or not value.strip():
        fail(f"{package_name}: game.json의 '{key}' 값이 필요합니다.")
    value = value.strip()
    if len(value) > max_len:
        fail(f"{package_name}: '{key}' 값은 {max_len}자 이하여야 합니다.")
    return value


def optional_text(manifest: dict, key: str, default: str, max_len: int) -> str:
    value = manifest.get(key, default)
    return value.strip()[:max_len] if isinstance(value, str) else default


def validate_manifest(manifest: dict, package_name: str) -> dict:
    game_id = required_text(manifest, "id", package_name, 50).lower()
    if not ID_PATTERN.fullmatch(game_id):
        fail(f"{package_name}: id는 영문 소문자·숫자·하이픈만 사용한 3~50자여야 합니다.")

    title = required_text(manifest, "title", package_name, 60)
    description = required_text(manifest, "description", package_name, 260)
    tags = manifest.get("tags", [])
    if not isinstance(tags, list) or any(not isinstance(tag, str) for tag in tags):
        fail(f"{package_name}: tags는 문자열 배열이어야 합니다.")
    tags = [tag.strip()[:24] for tag in tags if tag.strip()][:4]

    accent = optional_text(manifest, "accent", "#62f5ff", 7)
    accent2 = optional_text(manifest, "accent2", "#a77cff", 7)
    if not COLOR_PATTERN.fullmatch(accent):
        accent = "#62f5ff"
    if not COLOR_PATTERN.fullmatch(accent2):
        accent2 = "#a77cff"

    record = manifest.get("record", {})
    if not isinstance(record, dict):
        record = {}
    storage_key = record.get("storageKey")
    if storage_key is not None and not isinstance(storage_key, str):
        storage_key = None
    fallback = record.get("fallback", 0)
    if not isinstance(fallback, (int, float, str)):
        fallback = 0

    order = manifest.get("order", 1000)
    if not isinstance(order, (int, float)):
        order = 1000

    cover = manifest.get("cover")
    if cover is not None:
        cover = str(normalize_member(cover.strip())) if isinstance(cover, str) and cover.strip() else None

    return {
        "id": game_id,
        "title": title,
        "shortTitle": optional_text(manifest, "shortTitle", title, 24),
        "description": description,
        "genre": optional_text(manifest, "genre", "BROWSER GAME", 42),
        "tags": tags,
        "version": optional_text(manifest, "version", "v1.0", 20),
        "badge": optional_text(manifest, "badge", "", 16),
        "buttonLabel": optional_text(manifest, "buttonLabel", "PLAY NOW", 20),
        "accent": accent,
        "accent2": accent2,
        "preview": optional_text(manifest, "preview", "generic", 30),
        "cover": cover,
        "featured": bool(manifest.get("featured", False)),
        "order": order,
        "record": {
            "storageKey": storage_key,
            "label": optional_text(record, "label", "LOCAL RECORD", 30),
            "prefix": optional_text(record, "prefix", "", 12),
            "suffix": optional_text(record, "suffix", "", 12),
            "format": optional_text(record, "format", "number", 10),
            "fallback": fallback,
        },
    }


def copy_public() -> None:
    if not PUBLIC.exists():
        fail("코어 ZIP의 public 폴더가 없습니다.")
    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    shutil.copytree(PUBLIC, OUTPUT)
    (OUTPUT / "games").mkdir(parents=True, exist_ok=True)


def extract_package(package_path: Path, known_ids: set[str]) -> dict:
    with zipfile.ZipFile(package_path) as archive:
        infos = [info for info in archive.infolist() if not info.is_dir()]
        if len(infos) > MAX_FILES:
            fail(f"{package_path.name}: 파일 수가 {MAX_FILES}개를 초과합니다.")
        if sum(info.file_size for info in infos) > MAX_UNCOMPRESSED_BYTES:
            fail(f"{package_path.name}: 압축 해제 크기가 200MB를 초과합니다.")
        if any(is_symlink(info) for info in infos):
            fail(f"{package_path.name}: 심볼릭 링크는 허용되지 않습니다.")

        normalized = [(info, normalize_member(info.filename)) for info in infos]
        paths = [path for _, path in normalized]
        base = find_manifest_base(paths, package_path.name)
        manifest_path = base / "game.json"
        manifest_info = next(info for info, path in normalized if path == manifest_path)
        manifest = validate_manifest(read_manifest(archive, manifest_info.filename, package_path.name), package_path.name)
        game_id = manifest["id"]
        if game_id in known_ids:
            fail(f"중복 게임 id '{game_id}'가 발견되었습니다.")
        known_ids.add(game_id)

        relative_files: list[tuple[zipfile.ZipInfo, PurePosixPath]] = []
        for info, path in normalized:
            try:
                relative = path.relative_to(base) if base.parts else path
            except ValueError:
                continue
            if not relative.parts or relative.name == ".DS_Store" or "__MACOSX" in relative.parts:
                continue
            relative_files.append((info, relative))

        relative_names = {str(relative) for _, relative in relative_files}
        if "index.html" not in relative_names:
            fail(f"{package_path.name}: game.json과 같은 위치에 index.html이 필요합니다.")
        if manifest["cover"] and manifest["cover"] not in relative_names:
            fail(f"{package_path.name}: cover 파일 '{manifest['cover']}'을 찾을 수 없습니다.")

        destination = OUTPUT / "games" / game_id
        destination.mkdir(parents=True, exist_ok=False)
        for info, relative in relative_files:
            target = destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)

        entry = {key: value for key, value in manifest.items() if key != "order"}
        entry["href"] = f"games/{game_id}/"
        if manifest["cover"]:
            entry["cover"] = f"games/{game_id}/{manifest['cover']}"
        entry["sourcePackage"] = package_path.name
        entry["_order"] = manifest["order"]
        return entry


def collect_packages() -> list[Path]:
    packages = sorted(BUILTIN_PACKAGES.glob("*.zip"), key=lambda p: p.name.lower())
    # 아이패드 웹 업로드용: 저장소 최상단의 game-*.zip을 자동 인식합니다.
    external = sorted(REPOSITORY.glob("game-*.zip"), key=lambda p: p.name.lower())
    return packages + external


def build() -> None:
    copy_public()
    games: list[dict] = []
    known_ids: set[str] = set()
    packages = collect_packages()
    if not packages:
        fail("게임 패키지를 찾지 못했습니다.")

    for package in packages:
        print(f"[build] {package.name}")
        games.append(extract_package(package, known_ids))

    games.sort(key=lambda item: (item.pop("_order"), item["title"].casefold()))
    catalog = {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "gameCount": len(games),
        "games": games,
    }
    (OUTPUT / "games" / "catalog.json").write_text(
        json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(f"[done] {len(games)}개 게임을 빌드했습니다.")


if __name__ == "__main__":
    try:
        build()
    except (BuildError, zipfile.BadZipFile) as exc:
        print(f"BUILD ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
